<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background: url('https://files.vlad.studio/joy/books/preview/1280x800.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #333;
        }
        .container { 
			width: 600px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        .card {
            background-color: #f6e5d4;
            padding: 50px;
            border-radius: 15px;
            width: 100%;
            max-width: 400px;
            position: relative;
            overflow: hidden;
        }
        .card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, #a777e3, #6e8efb);
            z-index: -1;
            transform: rotate(45deg);
        }
        .card img {
            margin-bottom: 20px;
            width: 80px;
        }
        .card h1 {
            font-family: Garamond;
            font-size: 24px;
            margin-bottom: 20px;
            color: #444;
        }
        .card form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .card label {
            font-family: Garamond;
            margin-bottom: 15px;
            color: #555;
            text-align: left;
            font-weight: bold;
        }
        .card input {
			width: 94.5%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            margin-top: 5px;
            transition: all 0.3s ease;
        }
        .card input:focus {
            border-color: #6e8efb;
            box-shadow: 0 0 5px rgba(110, 142, 251, 0.5);
        }
        .card .btn {
            padding: 10px;
            background-color: #c9785b;
            border: none;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .card .btn:hover {
            background-color: #a85336;
        }
        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 8px;
            color: #856404;
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            text-align: left;
        }
        .text-center {
            text-align: center;
        }
        .text-muted {
            color: #6c757d;
        }
        .error-message {
            color: #d9534f;
            display: none;
            font-size: 14px;
            text-align: left;
            margin-top: 2px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <?php if(session() -> getFlashdata('pesan')): ?>
                <div class="alert">
                    <?= session()->getFlashdata('pesan') ?>
                </div>
            <?php endif?>

            <?php if(session() -> getFlashdata('error')): ?>
                <div class="alert">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif?>

            <h1>Login</h1>
            <form id="loginForm" action="<?= base_url('/login')?>" method="POST" novalidate="">
                <div>
                    <label for="user_name">User Name</label><br>
                    <input id="user_name" type="text" name="username" required>
                    <div class="error-message" id="usernameError">Username is required</div>
                </div>

                <div>
                    <label for="email">E-Mail Address</label><br>
                    <input id="email" type="email" name="email" required>
                    <div class="error-message" id="emailError">Email is invalid</div>
                </div>

                <div>
                    <label for="password">Password</label><br>
                    <input id="password" type="password" name="password" required>
                    <div class="error-message" id="passwordError">Password is required</div>
                </div>

                <button type="submit" class="btn">Login</button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            let isValid = true;

            const username = document.getElementById('user_name');
            const email = document.getElementById('email');
            const password = document.getElementById('password');

            const usernameError = document.getElementById('usernameError');
            const emailError = document.getElementById('emailError');
            const passwordError = document.getElementById('passwordError');

            if (!username.value) {
                isValid = false;
                usernameError.style.display = 'block';
            } else {
                usernameError.style.display = 'none';
            }

            if (!email.value || !email.validity.valid) {
                isValid = false;
                emailError.style.display = 'block';
            } else {
                emailError.style.display = 'none';
            }

            if (!password.value) {
                isValid = false;
                passwordError.style.display = 'block';
            } else {
                passwordError.style.display = 'none';
            }

            if (!isValid) {
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
