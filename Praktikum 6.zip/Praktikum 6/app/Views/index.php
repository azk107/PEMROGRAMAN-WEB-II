<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda</title>
    <style>
        body {
            font-family: Garamond;
            background: url('https://files.vlad.studio/joy/treeofbooks/preview/1280x800.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #050000;
            color: #ffffff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-family: Garamond;
            margin: 0;
            font-size: 24px;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
            text-decoration: none;
        }
        .content {
            padding: 20px;
        }
        h2 {
            font-size: 25px;
            color: #ffffff;
            margin-top: 30px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            background-color: #f6e5d4;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        th {
            background-color: #050000;
            color: #ffffff;
            font-size: 18px;
            padding: 12px;
            text-align: center;
        }
        td {
            padding: 12px;
        }
        .edit-btn {
            background-color: #ffc107;
            color: #333;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .edit-btn:hover {
            background-color: #e0a800;
            text-decoration: none;
        }
        .delete-btn {
            background-color: #dc3545;
            color: #ffffff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .delete-btn:hover {
            background-color: #c82333;
            text-decoration: none;
        }
        .add-btn {
            background-color: #c9785b;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
            display: inline-block; 
            margin-top: 20px; 
        }
        .add-btn:hover {
            background-color: #a85336;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>Selamat Datang di Database Perpustakan</h1>
        </div>
        <div>
            <a href="<?= base_url('/logout')?>" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="content">
        <h2>Daftar Buku</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data as $row): ?>
                    <tr>
                        <td><?= $row['judul'] ?></td>
                        <td><?= $row['penulis'] ?></td>
                        <td><?= $row['penerbit'] ?></td>
                        <td><?= $row['tahun_terbit'] ?></td>
                        <td>
                            <a href="<?= base_url('/editdata/'.$row['id']) ?>" class="edit-btn">Edit</a>
                            <form action="<?= base_url('/hapusdata/'.$row['id'])?>" style="display: inline;" method="post">
                                <input type="hidden" name="_method" value="DELETE">
                                <button class="delete-btn" type="submit" onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
        <div>
            <a href="<?= base_url('/tambahdata')?>" class="add-btn">Tambah Data</a>
        </div>
    </div>

</body>
</html>
