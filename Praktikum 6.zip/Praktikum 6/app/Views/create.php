<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <style>
        body,
        html {
            height: 100%;
            margin: 0;
            font-family: Garamond;
            background: url('https://files.vlad.studio/joy/books/preview/1280x800.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #333;
        }
        .container {
            width: 600px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        .card {
            background-color: #f6e5d4;
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            position: relative;
            overflow: hidden;
        }
        .card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, #a777e3, #6e8efb);
            z-index: -1;
            transform: rotate(45deg);
        }
        .card h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #444;
            text-align: center;
        }
        .card form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .card label {
            margin-bottom: 15px;
            color: #555;
            text-align: left;
            font-weight: bold;
        }
        .card input {
            width: 94.5%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .card input:focus {
            border-color: #6e8efb;
            box-shadow: 0 0 5px rgba(110, 142, 251, 0.5);
        }
        .card .btn {
            font-family: Garamond;
            padding: 10px;
            background-color: #c9785b;
            border: none;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
            text-decoration: none; 
            display: inline-block; 
            text-align: center; 
            width: 100%; 
        }
        .card .btn:hover {
            background-color: #a85336;
        }
        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #fff;
            background-color: #343a40; 
            padding: 10px; 
            border-radius: 8px; 
            font-size: 18px; 
            text-decoration: none; 
            transition: background-color 0.3s ease; 
        }
        .back-link:hover {
            background-color: #1d2124; 
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <h2>Tambah Data Buku</h2>
            <form action="<?= base_url('/tambahdata') ?>" method="post">
                <div>
                    <label for="judul" class="form-label">Judul</label>
                    <input name="judul" type="text" id="judul" required>
                </div>
                <div>
                    <label for="penulis" class="form-label">Penulis</label>
                    <input type="text" id="penulis" name="penulis" required>
                </div>
                <div>
                    <label for="penerbit" class="form-label">Penerbit</label>
                    <input type="text" id="penerbit" name="penerbit" required>
                </div>
                <div>
                    <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                    <input type="number" min="1800" max="2024" id="tahun_terbit" name="tahun_terbit" required>
                </div>
                <button type="submit" class="btn">Tambah</button>
            </form>
            <a href="<?= base_url('/kembali') ?>" class="back-link">Kembali</a>
        </div>
    </div>
</body>

</html>