<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\UserModel;

class UserSeeder extends Seeder
{
    public function run()
    {
        $model = new UserModel();

        //panggil methdo insert
        $model->insert([
            "username"=> "azka",
            "email"=> "azka@gmail.com",
            "password" => password_hash("788908",PASSWORD_DEFAULT),
        ]);
    }
}
